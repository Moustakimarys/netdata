Icons provided by [IconsDB.com](http://www.iconsdb.com/red-icons/seo-performance-icon.html)
