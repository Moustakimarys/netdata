#!/bin/sh
autoreconf -ivf
